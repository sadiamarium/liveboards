module.exports = {
    title: 'CoronaBoard',
    description: 'Global Corona Dashboard powered by StickyBoard',
    meta_image: '/static/image/CoronaBoard_preview.png',
    favicon: '/static/image/favicon.png',
};
