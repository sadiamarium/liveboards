// src/sidebar/SidebarCategoryName.js

const SidebarCategoryName = {
    STATISTICS: 'STATISTICS',
}

export default SidebarCategoryName;
