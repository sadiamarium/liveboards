// src/constants/LocalStorageConst.js

var LocalStorageConst = {
    KEY: {
        THEME_KEY: 'theme_key',
        SELECTED_COUNTRY: 'selected_country',
    },
}

export default LocalStorageConst
